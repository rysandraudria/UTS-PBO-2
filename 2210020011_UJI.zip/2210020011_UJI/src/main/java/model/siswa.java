package com.uji.model;

public class Siswa {
    private int idSiswa;
    private String namaSiswa;
    private String nis;
    private String jenkel;
    private String foto;

    // Getter dan Setter
}