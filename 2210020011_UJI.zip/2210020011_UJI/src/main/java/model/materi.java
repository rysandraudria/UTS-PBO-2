package com.uji.model;

public class Materi {
    private int idMateri;
    private int idGuru;
    private int idAdmin;
    private String judulMateri;
    private String deskripsiMateri;
    private String tanggal;
    private String penerbit;
    private int downloadMateri;
    private int idKelas;
    private int idSiswa;
    private String dataMateri;

    // Getter dan Setter
}