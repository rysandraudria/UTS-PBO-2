package com.uji.model;

public class Admin {
    private int idAdmin;
    private String namaAdmin;
    private String motoAdmin;
    private String jenkelAdmin;
    private String username;
    private String password;
    private String tentang;
    private String email;
    private String noHandphone;
    private String registerAdmin;
    private String foto;

    // Getter dan Setter
}