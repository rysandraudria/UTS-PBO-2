package com.uji.model;

public class Guru {
    private int idGuru;
    private int idAdmin;
    private String namaGuru;
    private int idMateri;
    private String nip;
    private String jenkel;
    private String tempatLahir;
    private String tanggalLahir;
    private String photo;
    private String tanggalInputGuru;

    // Getter dan Setter
}