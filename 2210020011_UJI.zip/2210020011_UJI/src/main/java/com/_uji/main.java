package com.uji.app;

import com.uji.dao.AdminDAO;
import com.uji.model.Admin;

import java.util.List;

public class MainApp {
    public static void main(String[] args) {
        AdminDAO adminDAO = new AdminDAO();
        List<Admin> admins = adminDAO.getAllAdmins();
        
        for (Admin admin : admins) {
            System.out.println("Nama Admin: " + admin.getNamaAdmin());
        }
    }
}