package com.uji.dao;

import com.uji.database.DatabaseConnection;
import com.uji.model.Admin;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class AdminDAO {
    public List<Admin> getAllAdmins() {
        List<Admin> admins = new ArrayList<>();
        String query = "SELECT * FROM admin";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                Admin admin = new Admin();
                admin.setIdAdmin(rs.getInt("id_admin"));
                admin.setNamaAdmin(rs.getString("nama_admin"));
                admin.setMotoAdmin(rs.getString("moto_admin"));
                admin.setJenkelAdmin(rs.getString("jenkel_admin"));
                admin.setUsername(rs.getString("username"));
                admin.setPassword(rs.getString("password"));
                admin.setTentang(rs.getString("tentang"));
                admin.setEmail(rs.getString("email"));
                admin.setNoHandphone(rs.getString("no_handphone"));
                admin.setRegisterAdmin(rs.getString("register_admin"));
                admin.setFoto(rs.getString("foto"));
                admins.add(admin);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return admins;
    }
}